package com.lagou.module01.filter;

import com.lagou.module01.entity.User;

import javax.servlet.*;
import javax.servlet.Filter;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(filterName = "LoginFilter",urlPatterns = {"/index.jsp","/manageStudent.jsp","/Choose.jsp"})
public class LoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        //1.实现对用户访问主页的过滤操作，只有登录后才能访问主页面，否则一律拦截
        HttpServletRequest httpServletRequest = (HttpServletRequest)req;
        //2.判断session中是否已有用户名信息，若有则放行，若内有则判断Cookie中是否有，有放行，没有拦截
        HttpSession session = httpServletRequest.getSession();
        User user=(User) session.getAttribute("user");
        String servletPath = httpServletRequest.getServletPath();
        String userName = null;
        if (null != user && servletPath.contains("adminLoginServlet")){
            chain.doFilter(req,resp);
        }else {
            //若没有登录，查询cookie信息中是否已经保存账号和密码
            Cookie[] cookies = httpServletRequest.getCookies();
            if(cookies!=null&&cookies.length>0){
                for (Cookie c :
                        cookies) {
                    String name = c.getName();
                    if("userName".equals(name)){
                        userName = name;
                    }
                }
            }
        }
        if(null != userName){
            chain.doFilter(req,resp);
        }else {
            req.getRequestDispatcher("index.jsp").forward(req,resp);
        }
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
