package com.lagou.module01.test;

import com.lagou.module01.entity.Class;
import com.lagou.module01.service.ClassServiceImpl;

import java.util.List;

public class ClassTest {

    public static void main(String[] args) {
        ClassServiceImpl classService = new ClassServiceImpl();
        List<Class> classList = classService.classList();
        System.out.println("读取到的信息有");
        for (Class c :
                classList) {
            System.out.println(c);
        }
    }
}
