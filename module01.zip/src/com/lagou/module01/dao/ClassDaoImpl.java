package com.lagou.module01.dao;

import com.lagou.module01.entity.Class;
import com.lagou.module01.util.DruidUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClassDaoImpl implements ClassDao {
    @Override
    public List<Class> classShow() {
        List<Class> classList = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DruidUtils.getConnection();
            String sql = "select * from t_class";
            preparedStatement =connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            classList = new ArrayList<>();
            while (resultSet.next()){
                Class c = new Class(resultSet.getInt("classId"),resultSet.getString("className"),resultSet.getString("classTeacher"),resultSet.getString("classNumber"));
                classList.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DruidUtils.close(connection,preparedStatement,resultSet);
        }
        return classList;
    }

    @Override
    public int classAdd(Class c) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = DruidUtils.getConnection();
            String sql = "insert into t_class values(null ,?,?,?)";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1,c.getClassName());
            preparedStatement.setString(2,c.getClassTeacher());
            preparedStatement.setString(3,c.getClassNumber());
            return preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DruidUtils.close(connection,preparedStatement);
        }
        return 0;
    }

    @Override
    public int classDel(String id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = DruidUtils.getConnection();

            String sql = "delete from t_class where classId = " + id +";";
            preparedStatement = connection.prepareStatement(sql);
            return preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DruidUtils.close(connection,preparedStatement);
        }
        return 0;
    }
}
