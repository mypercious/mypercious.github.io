package com.lagou.module01.dao;

import com.lagou.module01.entity.Class;

import java.util.List;

public interface ClassDao {

    List<Class> classShow();
    int classAdd(Class c);
    int classDel(String id);

}
