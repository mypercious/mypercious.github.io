package com.lagou.module01.servlet;

import com.lagou.module01.service.ClassService;
import com.lagou.module01.service.ClassServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ClassDelServlet",urlPatterns = "/classDelServlet")
public class ClassDelServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        String classId = request.getParameter("classId");
        ClassService classService = new ClassServiceImpl();
        int i = classService.classDel(classId);
        PrintWriter printWriter = response.getWriter();
        if (i == 1){
            printWriter.print("<script>alert('管理学生信息成功！');</script>");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("classManageServlet");
            requestDispatcher.forward(request,response);
        }
        if (i == 0){
            printWriter.print("<script>alert('管理学生信息失败！');</script>");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("classManageServlet");
            requestDispatcher.forward(request,response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
