package com.lagou.module01.servlet;

import com.lagou.module01.entity.Class;
import com.lagou.module01.service.ClassService;
import com.lagou.module01.service.ClassServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ClassAddServlet",urlPatterns = "/classAddServlet")
public class ClassAddServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");

        String className = request.getParameter("name");
        String classTeacher = request.getParameter("teacher");
        String classNumber = request.getParameter("number");
        Class c = new Class(className,classTeacher,classNumber);
        ClassService classService = new ClassServiceImpl();
        int i = classService.classAdd(c);
        PrintWriter printWriter = response.getWriter();
        if (i == 1){
            printWriter.print("<script>alert('管理班级信息成功！');</script>");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("classManageServlet");
            requestDispatcher.forward(request,response);
        }
        if (i == 0){
            printWriter.print("<script>alert('管理班级信息失败！');</script>");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("classManageServlet");
            requestDispatcher.forward(request,response);
        }


        RequestDispatcher requestDispatcher = request.getRequestDispatcher("classManageServlet");
        requestDispatcher.forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }
}
