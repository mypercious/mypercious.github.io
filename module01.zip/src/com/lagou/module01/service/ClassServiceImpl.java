package com.lagou.module01.service;

import com.lagou.module01.dao.ClassDao;
import com.lagou.module01.entity.Class;
import com.lagou.module01.factory.DaoFactory;

import java.lang.ref.PhantomReference;
import java.util.List;

public class ClassServiceImpl implements ClassService {

    private ClassDao classDao;

    public ClassServiceImpl(){
        classDao = DaoFactory.getClassDao();
    }
    @Override
    public List<Class> classList() {
        return classDao.classShow();
    }

    @Override
    public int classAdd(Class c) {
        return classDao.classAdd(c);
    }

    @Override
    public int classDel(String id) {
        return classDao.classDel(id);
    }
}
