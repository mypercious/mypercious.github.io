package com.lagou.module01.service;

import com.lagou.module01.entity.Class;

import java.util.List;

public interface ClassService {

    List<Class> classList();
    int classAdd(Class c);
    int classDel(String id);
}
