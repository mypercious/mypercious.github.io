package com.lagou.module01.entity;

public class Class {
    private int classId;
    private String className;
    private String classTeacher;
    private String classNumber;

    public Class(int classId, String className, String classTeacher, String classNumber) {
        this.classId = classId;
        this.className = className;
        this.classTeacher = classTeacher;
        this.classNumber = classNumber;
    }
    public Class( String className, String classTeacher, String classNumber) {

        this.className = className;
        this.classTeacher = classTeacher;
        this.classNumber = classNumber;
    }

    public Class() {
    }

    public int getClassId() {
        return classId;
    }

    public void setClassId(int classId) {
        this.classId = classId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassTeacher() {
        return classTeacher;
    }

    public void setClassTeacher(String classTeacher) {
        this.classTeacher = classTeacher;
    }

    public String getClassNumber() {
        return classNumber;
    }

    public void setClassNumber(String classNumber) {
        this.classNumber = classNumber;
    }

    @Override
    public String toString() {
        return "Class{" +
                "classId=" + classId +
                ", className='" + className + '\'' +
                ", classTeacher='" + classTeacher + '\'' +
                ", classNumber='" + classNumber + '\'' +
                '}';
    }
}
